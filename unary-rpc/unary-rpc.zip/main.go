package main

import (
	"github.com/HunCoding/golang-grpc/unary-rpc/server"
)

func main() {
	server.Run()
	//client.Run()
}
